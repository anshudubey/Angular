
import React from 'react';
import ReactDOM from 'react-dom/client';

const InvestmentWidget = () => (
  <div>
    <h2>📊 Investment Widget</h2>
    <p>Live Market Trends: S&P 500 +1.23%</p>
    <h3>Portfolio Allocation</h3>
    <ul>
      <li>Stocks: 60%</li>
      <li>Bonds: 30%</li>
      <li>Cash: 10%</li>
    </ul>
  </div>
);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<InvestmentWidget />);
