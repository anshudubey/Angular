
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: \`
    <div>
      <h2>🏦 Account Summary</h2>
      <p>Account: 123456789</p>
      <p>Balance: $12,345.67</p>
      <h3>🧾 Transaction History</h3>
      <table border="1">
        <tr><th>Date</th><th>Description</th><th>Amount</th></tr>
        <tr><td>2025-06-01</td><td>Grocery</td><td>-$120.00</td></tr>
        <tr><td>2025-06-02</td><td>Salary</td><td>+$3,000.00</td></tr>
      </table>
    </div>
  \`,
})
export class AppComponent {}
