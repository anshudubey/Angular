
console.log('Container app bootstrapped - host for Angular and React MFEs');
