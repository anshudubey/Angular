
const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin');
const path = require('path');

module.exports = {
  output: {
    publicPath: 'http://localhost:4200/',
    uniqueName: 'containerApp',
  },
  plugins: [
    new ModuleFederationPlugin({
      remotes: {
        angularApp: 'angularApp@http://localhost:4201/remoteEntry.js',
        reactApp: 'reactApp@http://localhost:4202/remoteEntry.js',
      },
    }),
  ],
};
